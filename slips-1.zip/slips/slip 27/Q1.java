import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Q1 extends JFrame 
{
    private JTable collegeTable;
    private JScrollPane scrollPane;

    public Q1() 
    {
        setTitle("College Details");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Object[][] data = 
        {
                {1, "ABC College", "123 Main St, City", 2020},
                {2, "XYZ College", "456 Oak St, Town", 2018},
        };

        String[] columnNames = {"CID", "CName", "Address", "Year"};

        DefaultTableModel model = new DefaultTableModel(data, columnNames);

        collegeTable = new JTable(model);

        collegeTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        collegeTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        collegeTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        collegeTable.getColumnModel().getColumn(3).setPreferredWidth(100);

        scrollPane = new JScrollPane(collegeTable);

        add(scrollPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> {
            Q1 frame = new Q1();
            frame.setVisible(true);
        });
    }
}
