
import java.util.LinkedList;

public class Q2 
{
    public static void main(String[] args) 
    {
        
        Buffer buffer = new Buffer(5);

        
        Thread producerThread = new Thread(new Producer(buffer));
        Thread consumerThread = new Thread(new Consumer(buffer));

        producerThread.start();
        consumerThread.start();
    }
}

class Buffer 
{
    private LinkedList<Integer> buffer;
    private int capacity;

    public Buffer(int capacity) 
    {
        this.buffer = new LinkedList<>();
        this.capacity = capacity;
    }

    public synchronized void produce(int value) 
    {
        while (buffer.size() == capacity) 
        {
            try 
            {
                wait();
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
        buffer.add(value);
        System.out.println("Produced: " + value);
        notify(); 
    }

    public synchronized int consume() 
    {
        while (buffer.size() == 0) 
        {
            try 
            {
                wait(); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        int value = buffer.remove();
        System.out.println("Consumed: " + value);
        notify(); 
        return value;
    }
}

class Producer implements Runnable 
{
    private Buffer buffer;

    public Producer(Buffer buffer) 
    {
        this.buffer = buffer;
    }

    @Override
    public void run()
    {
        for (int i = 1; i <= 10; i++) 
        {
            buffer.produce(i); 
        }
    }
}


class Consumer implements Runnable 
{
    private Buffer buffer;

    public Consumer(Buffer buffer) 
    {
        this.buffer = buffer;
    }

    @Override
    public void run() 
    {
        for (int i = 0; i < 10; i++) 
        {
            buffer.consume(); 
        }
    }
}


// Produced: 1
// Produced: 2
// Produced: 3
// Produced: 4
// Produced: 5
// Consumed: 1
// Consumed: 2
// Consumed: 3
// Consumed: 4
// Consumed: 5
// Produced: 6
// Produced: 7
// Produced: 8
// Produced: 9
// Produced: 10
// Consumed: 6
// Consumed: 7
// Consumed: 8
// Consumed: 9
// Consumed: 10