
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Q2 
{
    public static void main(String[] args) 
    {
        ArrayList<String> studentNames = new ArrayList<>();

        for (String arg : args) 
        {
            studentNames.add(arg);
        }

        System.out.println("Student names using Iterator:");
        Iterator<String> iterator = studentNames.iterator();
        while (iterator.hasNext()) 
        {
            System.out.println(iterator.next());
        }

        System.out.println("\nStudent names in reverse using ListIterator:");
        ListIterator<String> listIterator = studentNames.listIterator(studentNames.size());
        while (listIterator.hasPrevious()) 
        {
            System.out.println(listIterator.previous());
        }
    }
}
