import java.util.LinkedList;
import java.util.Scanner;

public class Q2 
{

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        int choice ; 
       do 
       {
        System.out.println("\nChoose operation:\n1. Add element at first position\n2. Delete last element\n3. Display the size of link list");
        System.out.println("Enter choice: ");
        choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter element to add first: ");
                    int ele = sc.nextInt();
                    linkedList.addFirst(ele);
                    System.out.println(linkedList);
                    
                    break;
                case 2:
                    linkedList.removeLast();
                    System.out.println("\nLinked list after deleting last element:");
                    System.out.println(linkedList);
                    break;
                case 3:
                    System.out.println("\nSize of the linked list: " + linkedList.size());
                    break;
                default:
                    System.out.println("Invalid choice!");
            }

            
        }while(choice!=3);
    }
    
}
