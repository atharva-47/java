
public class Q2 
{   
    public static void main(String[] args) 
    {
        Thread thread1 = new CustomThread("Thread 1");
        Thread thread2 = new CustomThread("Thread 2");

        thread1.start();
        thread2.start();
    }
}

class CustomThread extends Thread 
{
    public CustomThread(String name) 
    {
        super(name);
    }

    @Override
    public void run() 
    {
        try 
        {
            int sleepTime = (int) (Math.random() * 5000); 
            System.out.println(getName() + " is created with sleep time: " + sleepTime + " milliseconds");
            Thread.sleep(sleepTime); 
            System.out.println(getName() + " is dead");
        } 
        catch (InterruptedException e) 
        {
            e.printStackTrace();
        }
    }
}
