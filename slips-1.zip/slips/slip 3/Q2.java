import java.util.*;

public class Q2 
{
    public static void main(String[] args) 
    {
        LinkedList<String> list = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        list.add("Aditi");
        list.add("Akshata");
        list.add("vishakha");
       list.add("Diskha");

        int choice;
        String element;

        do 
        {
            System.out.println("\n1. Add element at the end of the list\n2. Delete first element of the list\n3. Display the content of list in reverse order\n4. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
           // scanner.nextLine();

            switch (choice) 
            {
                case 1:
                    System.out.print("Enter element to add: ");
                    element = scanner.next();
                    list.add(element);
                    break;
                case 2:
                        list.removeFirst();
                        System.out.println("First element deleted.");
                    break;
                case 3:
                        Collections.reverse(list);
                        System.out.println("\nList in reverse order:"+list);
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 4);  
    }
}
