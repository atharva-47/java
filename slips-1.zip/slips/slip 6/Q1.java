import java.util.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of integers (n): ");
        int n = sc.nextInt();
        
        Set<Integer> st = new TreeSet<>();
        
        System.out.println("Enter the integers:");
        for (int i = 0; i < n; i++) 
        {
            int num = sc.nextInt();
            st.add(num);
        }
        
        System.out.println("Integers in sorted order:");
        for(int num : st) 
        {
            System.out.print(num + " ");
        }
        System.out.println();
        

        System.out.print("Enter the element to search: ");
        int search = sc.nextInt();
        if (st.contains(search)) 
        {
            System.out.println("Element " + search + " found.");
        } 
        else 
        {
            System.out.println("Element " + search + " not found.");
        }
        
    }
}
