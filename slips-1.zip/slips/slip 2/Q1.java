import java.util.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        HashSet <String> set = new HashSet<String>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of your friends: ");   
        int n = sc.nextInt();
        for(int i=1;i<=n;i++)
        {
            System.out.println("Enter friends name: ");
            String str = sc.next();
            set.add(str);
        } 
        System.out.println("Friends name are: "+set);
        List<String> list = new ArrayList<String>(set);
        Collections.sort(list);
        System.out.println("Sorted name are: \n"+list);

    }
}
