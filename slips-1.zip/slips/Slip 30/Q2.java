import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q2 
{
    public static void main(String[] args) 
    {
        String url = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "your_username";
        String password = "your_password";
        
        try 
        {
            
            Connection connection = DriverManager.getConnection(url, username, password);
            
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Teacher");
            
            resultSet.last();
            
            int rowCount = resultSet.getRow();
            
            System.out.println("Total rows in Teacher table: " + rowCount);
            
            resultSet.beforeFirst();
            
            while (resultSet.next()) 
            {
                int tid = resultSet.getInt("TID");
                String tname = resultSet.getString("TName");
                double salary = resultSet.getDouble("Salary");
                
                System.out.println("TID: " + tid + ", TName: " + tname + ", Salary: " + salary);
            }
            
            resultSet.close();
            statement.close();
            connection.close();
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
}
