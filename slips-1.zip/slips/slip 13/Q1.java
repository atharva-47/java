
import java.sql.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "yourusername", "yourpassword")) 
        {
            DatabaseMetaData metaData = conn.getMetaData();

            System.out.println("Database Product Name: " + metaData.getDatabaseProductName());
            System.out.println("Database Product Version: " + metaData.getDatabaseProductVersion());
            System.out.println("Database Username: " + metaData.getUserName());

            ResultSet tablesResultSet = metaData.getTables(null, null, null, new String[]{"TABLE"});
            System.out.println("Tables in the database:");
            while (tablesResultSet.next()) 
            {
                String tableName = tablesResultSet.getString("TABLE_NAME");
                System.out.println(tableName);
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
}
