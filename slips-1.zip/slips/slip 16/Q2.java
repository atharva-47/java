import java.sql.*;

public class Q2
{
    public static void main(String[] args) 
    {
        try 
        {
			Connection conn=DriverManager.getConnection("jdbc:postgresql://192.168.100.10:5432/tybcs5","tybcs5","");

            String Query = "INSERT INTO Teacher VALUES (?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(Query);
            pst.setInt(1, 101);
            pst.setString(2, "Alisha");
            pst.setString(3, "JAVA");
            pst.executeUpdate();

            pst.setInt(1, 102);
            pst.setString(2, "Chandan");
            pst.setString(3, "PYTHON");
            pst.executeUpdate();

            pst.setInt(1, 103);
            pst.setString(2, "Dilip");
            pst.setString(3, "JAVA");
            pst.executeUpdate();

            pst.setInt(1, 104);
            pst.setString(2, "Ishika");
            pst.setString(3, "C++");
            pst.executeUpdate();

            pst.setInt(1, 105);
            pst.setString(2, "Manali");
            pst.setString(3, "JAVA");
            pst.executeUpdate();
            pst.close();

            String select = "SELECT * FROM Teacher WHERE Subject = ?";
            PreparedStatement st = conn.prepareStatement(select);
            st.setString(1, "JAVA");
            ResultSet resultSet = st.executeQuery();

            System.out.println("Details of teachers teaching JAVA:");
            while (resultSet.next()) 
            {
                int tno = resultSet.getInt("TNo");
                String tname = resultSet.getString("TName");
                String subject = resultSet.getString("Subject");
                System.out.println("TNo: " + tno + ", TName: " + tname + ", Subject: " + subject);
            }

            resultSet.close();
            st.close();
            conn.close();
        } 
        catch (SQLException ex) {}
    }
}
