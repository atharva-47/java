import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Q1 extends JFrame 
{
    private JLabel textLabel;
    private boolean visible = true;

    public Q1() 
    {
        setTitle("Blinking Text");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        textLabel = new JLabel("Blinking Text");
        add(textLabel);

        Thread thread = new Thread(new Runnable() 
        {
            public void run() 
            {
                try 
                {
                    while (true) 
                    {
                        Thread.sleep(500);
                        visible = !visible;
                        SwingUtilities.invokeLater(new Runnable() 
                        {
                            public void run() 
                            {
                                textLabel.setVisible(visible);
                            }
                        });
                    }
                } catch (InterruptedException e) 
                {
                    e.printStackTrace();
                }
            }
        });
        thread.start();

        setSize(300, 100);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) 
    {
        new Q1();
    }
}
