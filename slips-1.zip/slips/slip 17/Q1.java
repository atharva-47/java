
import java.util.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of integers (N): ");
        int N = scanner.nextInt();

        TreeSet<Integer> set = new TreeSet<>();

        System.out.println("Enter " + N + " integers:");
        for (int i = 0; i < N; i++) 
        {
            System.out.print("Enter integer " + (i + 1) + ": ");
            int num = scanner.nextInt();
            set.add(num);
        }
        System.out.println("\nIntegers in sorted order:");
        for (int num : set) 
        {
            System.out.println(num);
        }

        scanner.close();
    }
}
