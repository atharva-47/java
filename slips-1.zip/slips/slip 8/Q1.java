import java.util.*;

class text extends Thread
{
    String txt;
    int n;
    text(String txt, int n)
    {
        this.txt = txt;
        this.n = n;
    }
    public void run()
    {
        for(int i=0; i<=n; i++)
        {
            System.out.println(txt);
            try
            {
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
}
public class Q1 
{
    public static void main(String[] args) 
    {
        // text t1 = new text("COVID19", 10);
        // t1.start();
        text t2 = new text("LOCKDOWN2020",20); 
        t2.start();
        // text t3 = new text("VACCINATED2021", 30);
        // t3.start();
    }
}
