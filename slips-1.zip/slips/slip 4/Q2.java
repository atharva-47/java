import java.util.*;

public class Q2 
{
    public static void main(String[] args) 
    {
        Map<String, String> map = new HashMap<>();
        map.put("Pune", "020");
        map.put("Mumbai", "021");
        map.put("Kohlapur", "022");
        Scanner sc = new Scanner(System.in);
        int ch;

        do 
        {
            System.out.println("\n1. Add a new city and its code");
            System.out.println("2. Remove a city from collection");
            System.out.println("3. Search for a city name and display the code");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            ch = sc.nextInt();
            sc.nextLine(); 

            switch (ch) 
            {
                case 1:
                    System.out.print("Enter city name: ");
                    String city = sc.nextLine();
                    System.out.print("Enter STD code: ");
                    String std = sc.nextLine();
                    if (!map.containsKey(city)) 
                    {
                        map.put(city, std);
                        System.out.println("City added successfully.");
                    } 
                    else 
                    {
                        System.out.println("City already exists.");
                    }
                    break;
                case 2:
                    System.out.print("Enter city name to remove: ");
                    String remove = sc.nextLine();
                     map.remove(remove);
                    System.out.println("City removed successfully.");
                    break;
                case 3:
                    System.out.print("Enter city name to search: ");
                    String search = sc.nextLine();
                    if (map.containsKey(search)) 
                    {
                        System.out.println("STD code for " + search + ": " + map.get(search));
                    } 
                    else 
                    {
                        System.out.println("City not found.");
                    }
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (ch != 4);    
    }
}
