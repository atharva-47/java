
import java.util.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of subjects (N): ");
        int N = sc.nextInt();

        LinkedList<String> list = new LinkedList<>();

        System.out.println("Enter " + N + " subject names:");
        for (int i = 0; i < N; i++) 
        {
            System.out.print("Enter subject name " + (i + 1) + ": ");
            String sub = sc.next();
            list.add(sub);
        }

        System.out.println("\nSubject Names:");
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) 
        {
            System.out.println(iterator.next());
        }

        sc.close();
    }
}



