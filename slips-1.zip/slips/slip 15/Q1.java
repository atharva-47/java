
public class Q1 
{
    public static void main(String[] args) 
    {
        Thread thread = new Thread();

        System.out.println("Thread Name: " + thread.getName());

        System.out.println("Thread Priority: " + thread.getPriority());
    }
}