import java.util.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Hashtable<String, String> ht = new Hashtable<>();
        ht.put("77092883", "Aditi Bansod"); 
        ht.put("74938724", "Diksha Bansod"); 
        ht.put("98484938", "Akshta Bansod"); 
        ht.put("78889883", "komal dhume"); 

        int ch;
        do
        {
            System.out.println("\n1.Add Student Info \n2.Display Info \n3.Exiting Program");
            System.out.println("Enter your choice: ");
            ch = sc.nextInt();

            switch (ch) 
            {
                case 1:System.out.println("Enter mobile number: ");
                        String mobile = sc.next();
                        System.out.println("Enter student name:  ");
                        String name = sc.next();
                        ht.put(mobile, name);
                        break;
                case 2: System.out.println("Stutdent Info: ");
                        Enumeration<String> e = ht.keys();
                        while (e.hasMoreElements()) 
                        {
                            mobile = e.nextElement();
                            name = ht.get(mobile);
                            System.out.println(name+" "+mobile);
                        };
                        break;
                case 3: System.out.println("Exiting Program.....");
                        break;
            }
        }while(ch!=3);
     }
}
