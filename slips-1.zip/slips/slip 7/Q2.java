
import java.sql.*;

public class Q2
{
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/mydatabase"; 

    static final String USER = "username"; 
    static final String PASS = "password"; 

    public static void main(String[] args) 
    {

        Connection conn = null;
        Statement stmt = null;
        try 
        {
        
            Class.forName(JDBC_DRIVER);

            
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            
            System.out.println("Creating table...");
            stmt = conn.createStatement();
            String sql = "CREATE TABLE Product " +
                         "(Pid INT NOT NULL AUTO_INCREMENT, " +
                         " Pname VARCHAR(255), " +
                         " Price DECIMAL(10,2), " +
                         " PRIMARY KEY ( Pid ))";
            stmt.executeUpdate(sql);
            System.out.println("Table created successfully");

            System.out.println("Inserting records...");
            sql = "INSERT INTO Product (Pname, Price) VALUES ('Product1', 10.50)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Product (Pname, Price) VALUES ('Product2', 20.00)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Product (Pname, Price) VALUES ('Product3', 15.75)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Product (Pname, Price) VALUES ('Product4', 12.99)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO Product (Pname, Price) VALUES ('Product5', 25.49)";
            stmt.executeUpdate(sql);
            System.out.println("Records inserted successfully");


            System.out.println("Displaying all records...");
            sql = "SELECT * FROM Product";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) 
            {
                int pid = rs.getInt("Pid");
                String pname = rs.getString("Pname");
                double price = rs.getDouble("Price");
                System.out.println("Pid: " + pid + ", Pname: " + pname + ", Price: " + price);
            }
            rs.close();
        } 
        catch (SQLException se) 
        {
            se.printStackTrace();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
           
            try 
            {
                if (stmt != null) stmt.close();
            } 
            catch (SQLException se2) 
            {
                se2.printStackTrace();
            } 
            try 
            {
                if (conn != null) conn.close();
            } 
            catch (SQLException se) 
            {
                se.printStackTrace();
            } 
        } 
        System.out.println("Goodbye!");
    }
}
