import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class Q1 extends JPanel 
{
    private static final int WIDTH = 900;
    private static final int HEIGHT = 600;
    private static final Color SAFFRON = new Color(255, 153, 51);
    private static final Color GREEN = new Color(18, 136, 7);
    private static final Color BLUE_COLOR = Color.blue;

    private static final Color WHITE = Color.WHITE;

    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(SAFFRON);
        g2d.fillRect(0, 0, WIDTH, HEIGHT / 3);

        g2d.setColor(GREEN);
        g2d.fillRect(0, HEIGHT * 2 / 3, WIDTH, HEIGHT / 3);

        g2d.setColor(WHITE);
        g2d.fillRect(0, HEIGHT / 3, WIDTH, HEIGHT / 3);

        int diameter = HEIGHT / 3;
        int x = WIDTH / 2 - diameter / 2;
        int y = HEIGHT / 2 - diameter / 2;
        Ellipse2D.Double circle = new Ellipse2D.Double(x, y, diameter, diameter);
        g2d.setColor(BLUE_COLOR);
        g2d.fill(circle);

        for (int i = 0; i < 24; i++) 
        {
            double angle = Math.toRadians(i * 15);
            int startX = (int) (x + diameter / 2 * Math.cos(angle));
            int startY = (int) (y + diameter / 2 * Math.sin(angle));
            int endX = (int) (x + diameter / 2 * 0.9 * Math.cos(angle));
            int endY = (int) (y + diameter / 2 * 0.9 * Math.sin(angle));
            g2d.drawLine(startX, startY, endX, endY);
        }
    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> 
        {
            JFrame frame = new JFrame("Indian Flag");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Q1 flag = new Q1();
            frame.add(flag);
            frame.setSize(WIDTH, HEIGHT);
            frame.setVisible(true);
        });
    }
}
