import javax.swing.*;
import java.awt.*;

public class Q2 extends JPanel implements Runnable {
    private static final int WIDTH = 600;
    private static final int HEIGHT = 400;

    public Q2() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawTemple(g);
    }

    private void drawTemple(Graphics g) {
       
        g.setColor(Color.GRAY);
        g.fillRect(200, 200, 200, 150);

       
        g.setColor(Color.WHITE);
        g.fillRect(220, 150, 40, 200);
        g.fillRect(340, 150, 40, 200);

       
        int[] roofX = {200, 400, 300};
        int[] roofY = {200, 200, 100};
        g.setColor(Color.RED);
        g.fillPolygon(roofX, roofY, 3);

       
        g.setColor(Color.BLACK);
        g.fillRect(290, 250, 20, 100);
    }

    @Override
    public void run() 
    {
        while (true) 
        {
            repaint();
            try {
                Thread.sleep(100); 
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> 
        {
            JFrame frame = new JFrame("Temple Drawing");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new Q2());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            Thread thread = new Thread(new Q2());
            thread.start();
        });
    }
}
