import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Q2 extends HttpServlet 
{

    public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        String url = "jdbc:mysql://localhost:3306/mydatabase";
        String dbUsername = "your_username";
        String dbPassword = "your_password";

        String query = "SELECT * FROM users WHERE username=? AND password=?";
        
        try 
        {
           
            Class.forName("com.mysql.jdbc.Driver");

           
            Connection con = DriverManager.getConnection(url, dbUsername, dbPassword);

            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

           
            ResultSet rs = pstmt.executeQuery();


            if (rs.next()) 
            {
                out.println("<html><body>");
                out.println("<h2>Login Successful</h2>");
                out.println("<p>Welcome, " + username + "!</p>");
                out.println("</body></html>");
            } 
            else 
            {
                out.println("<html><body>");
                out.println("<h2>Login Failed</h2>");
                out.println("<p>Invalid username or password.</p>");
                out.println("</body></html>");
            }
            rs.close();
            pstmt.close();
            con.close();
        } 
        catch (Exception e) 
        {
            out.println("Exception: " + e);
        }

    }
}
