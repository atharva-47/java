import java.sql.*;

public class Q2 
{
    public static void main(String[] args) 
    {
        Connection con = null;
        ResultSet rs = null;
        Statement st = null;
        ResultSetMetaData rmd = null;
        int n;
        
        try{
            Class.forName("org.postgresql.driver");
            con = DriverManager.getConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from Donor");
            rmd = rs.getMetaData();

            n = rmd.getColumnCount();
            System.out.println("Number of table in Donor: "+n);

            System.out.println("No\tName\tType\tLabel\tDisplaySize\tReadonly\tWriteTable\tNull");
            for(int i=1;i<=n;i++)
            {
                System.out.println(i+"\t"
                                    +rmd.getColumnName(i)+"\t"
                                    +rmd.getColumnLabel(i)+"\t"
                                    +rmd.getColumnTypeName(i)+"\t"
                                    +rmd.getColumnDisplaySize(i)+"\t"
                                    +rmd.isReadOnly(i)+"\t"
                                    +rmd.isWritable(i)+"\t"
                                    +rmd.isNullable(i));
            }
        }
        catch(ClassNotFoundException cnf )
        {
            System.out.println(cnf);
        }
        catch(SQLException sql )
        {
            System.out.println(sql);
        }
        catch(Exception e )
        {
            System.out.println(e);
        }
    }    
}
