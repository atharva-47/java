
import java.util.*;

public class Q1
{
    public static void main(String[] args) 
    {
        TreeSet<String> colorSet = new TreeSet<>();

        colorSet.add("Red");
        colorSet.add("Green");
        colorSet.add("Blue");
        colorSet.add("Yellow");
        colorSet.add("Orange");

        
        System.out.println("Colors in ascending order:");
        for (String color : colorSet) 
        {
            System.out.println(color);
        }
    }
}