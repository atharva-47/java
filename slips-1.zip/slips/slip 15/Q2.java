
import java.io.IOException;
import javax.servlet.*;

@WebServlet("/VisitCounterServlet")
public class Q2 extends HttpServlet 
{
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        Cookie[] cookies = request.getCookies();
        
        int visitCount = 0;

        if (cookies != null) 
        {
            for (Cookie cookie : cookies) 
            {
                if (cookie.getName().equals("visitCount")) 
                {
                    visitCount = Integer.parseInt(cookie.getValue());
                    break;
                }
            }
        }

        visitCount++;

        Cookie visitCountCookie = new Cookie("visitCount", String.valueOf(visitCount));
        visitCountCookie.setMaxAge(24 * 60 * 60);

        
        response.addCookie(visitCountCookie);

        response.setContentType("text/html");

        response.getWriter().println("<html><head><title>Visit Counter Servlet</title></head><body>");

        if (visitCount == 1) 
        {
            response.getWriter().println("<h1>Welcome, First Time Visitor!</h1>");
        } 
        else 
        {
            response.getWriter().println("<h1>Welcome Back! You've visited this page " + visitCount + " times.</h1>");
        }

        response.getWriter().println("</body></html>");
    }
}

