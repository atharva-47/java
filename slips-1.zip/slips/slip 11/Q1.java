import java.io.*;
import java.net.*;
import java.net.http.HttpResponse;
import java.sql.*;


public class Q1 extends HttpServlet 
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws IOException, SQLException
    {
        PrintWriter out  = response.getWriter();
        String customerNo = request.getString("cno");
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, user, pass);
            ps = con.prepareStatement("SELECT * FROM customer WHERE customer_no = ?");
            ps.setString(1, customerNo);
            rs = ps.executeQuery();

            if(rs.next())
            {
                String customerName = rs.getString("customerName");
                String customerAddr = rs.getString("customerAddr");

                out.println("<html><body>");
                out.println("<h2>Customer Info<h2>");
                out.println("<p>Cutomer Number:"+customerNo+"</p>");
                out.println("<p>Cutomer Name:"+customerName+"</p>");
                out.println("<p>Cutomer Addr:"+customerAddr+"</p>");
                out.println("</body></html>");
            }
            else
            {
                request.SetContentType("text/html");
                out.println("<html><body>");
                out.println("<h2>error<h2>");
                out.println("Cutomer number "+customerNo+" Not found in table");
                out.println("</body></html>");
            }
        }
        catch(ClassNotFoundException cnf)
        {
            System.out.println(cnf);
        }
        catch(SQLException sql)
        {
            System.out.println(sql);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        finally{
            try 
            {
                if(rs!=null) rs.close();
                if(ps!=null) ps.close();
                if(con!=null) ps.close();
            } catch (SQLException e) 
            {
               System.out.println(e);
            }
        }
    }
}
