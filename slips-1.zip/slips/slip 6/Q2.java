import java.util.*;
public class Q2 
{
    public static void main(String[] args) 
    {
        Thread redThread = new Thread(new TrafficLight("RED", 5000)); 
        Thread yellowThread = new Thread(new TrafficLight("YELLOW", 2000)); 
        Thread greenThread = new Thread(new TrafficLight("GREEN", 7000)); 

        redThread.start();
        yellowThread.start();
        greenThread.start();
    }
}

class TrafficLight implements Runnable 
{
    private String color;
    private long duration;

    public TrafficLight(String color, long duration) 
    {
        this.color = color;
        this.duration = duration;
    }

    @Override
    public void run() 
    {
        while (true) 
        {
            System.out.println(color + " signal is on.");
            try 
            {
                Thread.sleep(duration);
            } 
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            toggleSignal();
        }
    }

    private void toggleSignal() 
    {
        switch (color) 
        {
            case "RED":
                color = "GREEN";
                duration = 7000; 
                break;
            case "YELLOW":
                color = "RED";
                duration = 5000; 
                break;
            case "GREEN":
                color = "YELLOW";
                duration = 2000; 
                break;
        }
    }
}