import java.util.*;

class randomT extends Thread
{
    public void run()
    {

        Random r  = new Random();
        while (true) 
        {
            try
            {
                int no = r.nextInt(5);

                System.out.println("Random Integers are :  "+no);

                if(no%2==0)
                {
                    Square sq = new Square(no);
                    sq.start();
                }
                else
                {
                    Cube cb = new Cube(no);
                    cb.start();
                }
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
class Square extends Thread
{
    int no;
    Square(int no)
    {
        this.no = no;
    }
    public void run()
    {
        System.out.println("It is even number......");
        System.out.println("Square of this:  "+(no*no));
    }
}
class Cube extends Thread
{
    int no;
    Cube(int no)
    {
        this.no = no;
    }
    public void run()
    {
        System.out.println("It is odd number......");
        System.out.println("cube of this:  "+(no*no*no));
    }
}

public class Q1{
    public static void main(String[] args) 
    {
        randomT rt = new randomT();
        rt.start();
    }
}
