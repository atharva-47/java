import java.io.*;
import java.util.concurrent.*;

public class Q1 
{
    public static void main(String[] args) 
    {
        
        String searchString = "example"; 

        
        File currentDir = new File(".");
        File[] files = currentDir.listFiles();

        ExecutorService executor = Executors.newFixedThreadPool(files.length);

        for (File file : files) 
        {
            if (file.isFile() && file.getName().endsWith(".txt")) 
            {
                executor.submit(new SearchTask(file, searchString));
            }
        }
        executor.shutdown();
    }
}

class SearchTask implements Runnable 
{
    private File file;
    private String searchString;

    public SearchTask(File file, String searchString) 
    {
        this.file = file;
        this.searchString = searchString;
    }

    @Override
    public void run() 
    {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) 
        {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) 
            {
                lineNumber++;
                if (line.contains(searchString)) 
                {
                    System.out.println("Found '" + searchString + "' in file: " + file.getName() + ", line: " + lineNumber);
                }
            }
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}


// Found 'example' in file: file1.txt, line: 1
// Found 'example' in file: file2.txt, line: 2
// Found 'example' in file: file2.txt, line: 3
